//
//  cusCollectionViewCell.swift
//  collViewInsideTableView
//
//  Created by Mac on 5/29/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit

class cusCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var collCellImage: UIImageView!
}
