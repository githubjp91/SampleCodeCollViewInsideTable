//
//  ViewController.swift
//  collViewInsideTableView
//
//  Created by Mac on 5/29/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource,UITableViewDelegate {
   
    
    
    var aryImageLogo = [UIImage]()
    
    
    @IBOutlet weak var tblView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        aryImageLogo = [#imageLiteral(resourceName: "volvo.jpeg"),#imageLiteral(resourceName: "jaguar.png"),#imageLiteral(resourceName: "toyota.jpeg"),#imageLiteral(resourceName: "bmw.jpeg"),#imageLiteral(resourceName: "farrari.jpeg"),#imageLiteral(resourceName: "honda.jpeg"),#imageLiteral(resourceName: "chev.jpeg"),#imageLiteral(resourceName: "wolks.jpeg"),#imageLiteral(resourceName: "oudi.jpeg"),#imageLiteral(resourceName: "nissan.jpeg"),#imageLiteral(resourceName: "hyundai.jpg")]
        
       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 20
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cusTableViewCell")as! cusTableViewCell
        
        cell.layer.cornerRadius = 15
        
        cell.collView.reloadData()
        
        return cell
    }

}
extension ViewController: UICollectionViewDelegate,UICollectionViewDataSource{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
    
        
        return aryImageLogo.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cusCollectionViewCell", for: indexPath)as! cusCollectionViewCell
        
        
      cell.layer.cornerRadius = cell.collCellImage.frame.height/2
        cell.collCellImage.image = aryImageLogo[indexPath.row]
      // cell.layer.borderColor = UIColor.red.cgColor
        cell.layer.borderWidth = 1.5
        cell.collCellImage.clipsToBounds = true
    
       
        
        return cell
    }
    
    
    
    
    
    
    
}
